# Jam Widget

Widget jam digital untuk layar utama Android: jam, menit, dan detik berjalan langsung, plus tanggal.
Ukuran bisa diubah-ubah. Tidak ada service latar belakang, angkanya digerakkan oleh TextClock.
