package com.example.jamwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/**
 * Angka jam digerakkan oleh TextClock di dalam widget (sistem yang mengupdate tiap detik),
 * jadi tidak ada service atau alarm yang berjalan di latar belakang.
 */
public class JamWidgetProvider extends AppWidgetProvider {
    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        PendingIntent open = PendingIntent.getActivity(context, 0,
            new Intent(context, MainActivity.class),
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        for (int id : ids) {
            RemoteViews rv = new RemoteViews(context.getPackageName(), R.layout.widget_clock);
            rv.setOnClickPendingIntent(R.id.widgetRoot, open);
            manager.updateAppWidget(id, rv);
        }
    }
}
