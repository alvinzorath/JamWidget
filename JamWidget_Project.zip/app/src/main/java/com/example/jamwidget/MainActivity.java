package com.example.jamwidget;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Android 15 menggambar app di bawah status/navigation bar.
        findViewById(R.id.root).setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets ins) {
                int pad = Math.round(24 * getResources().getDisplayMetrics().density);
                v.setPadding(pad + ins.getSystemWindowInsetLeft(),
                    pad + ins.getSystemWindowInsetTop(),
                    pad + ins.getSystemWindowInsetRight(),
                    pad + ins.getSystemWindowInsetBottom());
                return ins;
            }
        });

        findViewById(R.id.btnAdd).setOnClickListener(v -> {
            AppWidgetManager m = AppWidgetManager.getInstance(this);
            if (m.isRequestPinAppWidgetSupported()) {
                m.requestPinAppWidget(new ComponentName(this, JamWidgetProvider.class), null, null);
            } else {
                Toast.makeText(this,
                    "Tahan layar utama, pilih Widget, lalu cari Jam Widget.",
                    Toast.LENGTH_LONG).show();
            }
        });
    }
}
